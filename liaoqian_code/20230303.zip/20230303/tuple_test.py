# coding:utf-8

tuple_test = (1, 2, 3)
print(tuple_test)
print(type(tuple_test))

tuple_01 = ()
print(type(tuple_01))

print(bool((1,)))
print(len(tuple_01))

max_count = max(tuple_test)
print(max_count)
min_count = min(tuple_test)
print(min_count)
