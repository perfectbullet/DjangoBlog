# coding:utf-8

import os


print(os.getcwd())
