# coding:utf-8

name = 'dewei'
name_02 = '小慕'

print(id(name))
print(id(name_02))

new_name = name
print(id(new_name))

print(type(name))

info = """
          今天天气不错
       """
print(info)

info1 = 'asdf'
info2 = "asdf"

new_str = 'nihao dewei "nihao" dewei'
print(new_str)