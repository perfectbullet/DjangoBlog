# coding:utf-8

none_list = [None, None, None]

print(none_list)
print(bool(none_list))
print(len(none_list))
print([])
print(bool([]))

max_list = [1, 3.14]
print(max_list)
print(max(max_list))
print(min(max_list))

id_address = id(max_list)
print(id_address)
