# coding:utf-8

import os


if __name__ == '__main__':
    print(os.getcwd())
    print('123')

