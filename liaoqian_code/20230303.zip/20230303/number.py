# coding:utf-8

name = 'dewei'
age = 33
weight = 66.7


if __name__ == '__main__':
    print(name)
    print(age)
    print(weight)
    print(type(age))
    print(type(weight))
    print(type(50))
    print(type(3.14))
