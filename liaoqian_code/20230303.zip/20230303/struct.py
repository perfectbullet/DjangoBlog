# coding:utf-8

print('欢迎学习python就业课程')
print('今天天气不错')
